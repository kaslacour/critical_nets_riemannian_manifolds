function stat = DeleteVertices(X,xa,xb,oab,vertices_to_be_deleted)

    n = max([xa,xb]);
%     m = length(xa);
    old2new = [1:n;1:n];
    old2new(2,vertices_to_be_deleted) = 0;
    interior_vertices = find(old2new(2,:) ~=0);
    n_old = n;
    n = length(interior_vertices);
    old2new(2,interior_vertices) = 1:n;
   
    edges_int = find(old2new(2,xa)~=0 & old2new(2,xb)~=0);
    X_old = X;
    X = [X_old(interior_vertices); X_old(n_old+interior_vertices); X(2*n_old+edges_int)];
    
    xa = xa(edges_int);
    xa = old2new(2,xa);
    xa(xa == 0) = [];
    xb = xb(edges_int);
    xb = old2new(2,xb);
    xb(xb == 0) = [];
    oab = oab(edges_int);
    
    stat.X = X;
    stat.xa = xa;
    stat.xb = xb;
    stat.oab = oab;
end

