function [A,b,N_edges] = SetupLinearSystem(xa,xb,oab)
% Given an interior graph, find the equivilant system of linear equations

    r = [[cos(4*pi/3);sin(4*pi/3)], ... % south-south-west
        [1;0], ...                      % east
        [cos(2/3*pi);sin(2/3*pi)]];     % north-north-west

    % 'Ax=b' is the system of linear equations
    n = max([xa,xb]);
    m = length(xa);
    eps = 1.0e-2;
    
    A = zeros(3*m+2,2*n+m);
    b = zeros(3*m+2,1);
    for i=1:m
        A(i,[xa(i),xb(i),2*n+i]) = [1,-1,r(1,oab(i))];
        A(i+m,[xa(i)+n,xb(i)+n,2*n+i]) = [1,-1,r(2,oab(i))];
    end
    A(end-1:end,[1, 1+n]) = eye(2);
    N = null(A);
    N_edges = N(2*n+1:end,:);
    A(2*m+1:end-2,2*n+1:end) = eye(m);

end

