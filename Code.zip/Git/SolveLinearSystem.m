function stat = SolveLinearSystem(xa,xb,oab,D,str)

    r = [[cos(4*pi/3);sin(4*pi/3)], ... % south-south-west
        [1;0], ...                      % east
        [cos(2/3*pi);sin(2/3*pi)]];     % north-north-west

    % 'Ax=b' is the system of linear equations
    n = max([xa,xb]);
    m = length(xa);
    eps = 1.0e-1;
    
    A = zeros(3*m+2,2*n+m);
    b = zeros(3*m+2,1);
    for i=1:m
        A(i,[xa(i),xb(i),2*n+i]) = [1,-1,r(1,oab(i))];
        A(i+m,[xa(i)+n,xb(i)+n,2*n+i]) = [1,-1,r(2,oab(i))];
    end
    A(end-1:end,[1, 1+n]) = eye(2);
    dof = 2*n+m-rank(A);
    str = string(str);
    if str=="Random"
        N = null(A);
        S = randn(1,dof);
        N_edges = N(2*n+1:end,:);
        b_edges = S * N_edges';
        small = min(b_edges);
        if small <= 0 
            b_edges = b_edges - small + eps;
        end
        b(2*m+1:end-2) = b_edges / max(b_edges);
    elseif str=="Regular"
        b(2*m+1:end-2) = 1;
    else
        error('invalid input string');
    end
    A(2*m+1:end-2,2*n+1:end) = eye(m);
    X = A \ b;
    
    S = sparse([xa,xb],[xb,xa],ones(1,2*m),n,n,2*m);
    V = sum(S ~= 0);
    vertices = [X(1:n)';X(n+1:2*n)'];
    vertices_2 = vertices(:,V==2);
    
    fun = @(theta) fun_radius(theta,vertices_2);
    x0 = 0;
    theta_1 = fminsearch(fun,x0);
    v1 = [cos(theta_1);sin(theta_1)];
    v2 = [cos(theta_1+pi/2);sin(theta_1+pi/2)];
    l = fun(theta_1);
    magnitude = D / l;
    b(2*m+1:end-2) = magnitude * b(2*m+1:end-2);
    X = A \ b;
    vertices = [X(1:n)';X(n+1:2*n)'];
    vertices_2 = vertices(:,V==2);
    
    proj_v1 = dot(vertices_2,repmat(v1,1,size(vertices_2,2)));
    v1_min = min(proj_v1);
    v1_max = max(proj_v1);
    
    proj_v2 = dot(vertices_2,repmat(v2,1,size(vertices_2,2)));
    v2_min = min(proj_v2);
    v2_max = max(proj_v2);
    
    center = mean([v1_max,v1_min;v2_max,v2_min],2);
    center = ...
    [cos(theta_1), -sin(theta_1); sin(theta_1), cos(theta_1)] * center;
    
    X(1:n) = X(1:n) - center(1);
    X(n+1:2*n) = X(n+1:2*n) - center(2);
    
    stat.X = X;
    stat.num_bounds = size(vertices_2,2);
    stat.l = fun_radius(theta_1,vertices_2);
    stat.L = sum(X(2*n+1:end));
    stat.dof = dof;
    stat.xa = xa;
    stat.xb = xb;
    stat.oab = oab;
end

