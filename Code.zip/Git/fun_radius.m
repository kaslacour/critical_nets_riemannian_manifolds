function [f,center] = fun_radius(theta_1,outer_vertices)
    v1 = [cos(theta_1);sin(theta_1)];
    proj_v1 = dot(outer_vertices,repmat(v1,1,size(outer_vertices,2)));
    v1_min = min(proj_v1);
    v1_max = max(proj_v1);
    
    theta_2 = theta_1+pi/2;
    v2 = [cos(theta_2);sin(theta_2)];
    proj_v2 = dot(outer_vertices,repmat(v2,1,size(outer_vertices,2)));
    v2_min = min(proj_v2);
    v2_max = max(proj_v2);
    
    center = mean([v1_max,v1_min;v2_max,v2_min],2);
    center = ...
    [cos(theta_1), -sin(theta_1); sin(theta_1), cos(theta_1)] * center;
    
    
    l1 = norm(v1_max-v1_min,2);
    l2 = norm(v2_max-v2_min,2);
    f = norm([l1,l2],2);
end

