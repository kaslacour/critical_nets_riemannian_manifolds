function ratio = fun_ratio(S,A,b,N_edges,xa,xb)
    %Computes the ratio of given interior graph, for varying S
    
    m = length(xa);
%     n = max([xa,xb]);
    
    b_edges = S * N_edges';
    small = min(b_edges);
    if small <= 0 
        b_edges = b_edges - small + eps;
    end
    b(2*m+1:end-2) = b_edges;
    X = A \ b;
    
    ratio = CalculateRatio(X,xa,xb);
end

