function stat = CarvePacking(fun, X, xa, xb, oab, varargin)
    %CARVEWITHCURVE Carves the convex packing with given boundary curve.
    %   Returns the solution of a critical net, encapsulated by the given
    %   boundary curve.
    
    r = [[cos(4*pi/3);sin(4*pi/3)], ... % south-south-west
        [1;0], ...                      % east
        [cos(2/3*pi);sin(2/3*pi)]];     % north-north-west
    
    stat = [];
    
    n = max([xa,xb]);
    m = length(xa);
    % Ray casting
    p = feval(fun,pi/3,varargin{:});
    p = p(1:2,:);
    vertex_idx_new = ones(1,n) == 1;
    for k=1:n
        x0 = [X(k);X(k+n)];
        v = p - x0;
        v = v / norm(v,2);
        alpha = argument(fun,x0,v,varargin{:});

        alpha_0 = alpha (alpha == 0);

        if isempty(alpha_0)
            cuts = length(alpha (alpha < 0));
            if mod(cuts,2) == 0    
                vertex_idx_new(k) = false;
            end
        end
    end
    edge_idx_new = false(1,m);
    n_spawn = 2*m;
    vertex_spawn_idx = false(1,n_spawn);
    xa_spawn = zeros(1,n_spawn);
    xb_spawn = zeros(1,n_spawn);
    ab_spawn = zeros(1,n_spawn);
    vertices_spawn = zeros(2,n_spawn);
    edges_spawn = zeros(1,n_spawn);
    vertedge_idx = n;
    for k=1:m
        if vertex_idx_new(xa(k))
            k_a = 2*(k-1)+1;
            x0 = X([xa(k),xa(k)+n]);
            v = r(:,oab(k));
            alpha = argument(fun,x0,v,varargin{:});
            alpha = alpha( ~isnan(alpha) );
            alpha = alpha (alpha > 0);
            alpha = min(alpha);
            if alpha < X(k+2*n)
               vertex_spawn_idx(k_a) = 1;
               vertedge_idx = vertedge_idx+1;
               xa_spawn(k_a) = xa(k);
               xb_spawn(k_a) = vertedge_idx;
               ab_spawn(k_a) = oab(k);
               vertices_spawn(:,k_a) = x0 + alpha*v; 
               edges_spawn(k_a) = alpha;
            elseif vertex_idx_new(xb(k))
               edge_idx_new(k) = true;
            end
        end
        if vertex_idx_new(xb(k))
            k_b = 2*k;
            x0 = X([xb(k),xb(k)+n]);
            v = -r(:,oab(k));
            alpha = argument(fun,x0,v,varargin{:});
            alpha = alpha( ~isnan(alpha) );
            alpha = alpha (alpha > 0);
            alpha = min(alpha);
            if alpha < X(k+2*n)
                vertex_spawn_idx(k_b) = 1;
                vertedge_idx = vertedge_idx+1;
                xb_spawn(k_b) = xb(k);
                xa_spawn(k_b) = vertedge_idx;
                ab_spawn(k_b) = oab(k);
                vertices_spawn(:,k_b) = x0 + alpha*v; 
                edges_spawn(k_b) = alpha;
            end
        end
    end
    vertex_spawn_idx = find(vertex_spawn_idx);
    n_spawn = vertedge_idx - n;
    vertex_idx_new = [vertex_idx_new,ones(1,n_spawn)];
    edge_idx_new = [edge_idx_new,ones(1,n_spawn)];
    vertices_spawn = vertices_spawn(:,vertex_spawn_idx);
    edges_spawn = edges_spawn(vertex_spawn_idx);
    xa_spawn = xa_spawn(vertex_spawn_idx);
    xb_spawn = xb_spawn(vertex_spawn_idx);
    ab_spawn = ab_spawn(vertex_spawn_idx);

    X = [X(1:n); vertices_spawn(1,:)'; X(n+1:2*n); vertices_spawn(2,:)'; ...
        X(2*n+1:end); edges_spawn'];
    n = n + n_spawn;
%     m = m + n_spawn;
    xa = [xa,xa_spawn];
    xb = [xb,xb_spawn];
    oab = [oab,ab_spawn];

    vertex_old_to_new = [1:n;zeros(1,n)];
    temp = vertex_old_to_new(2,:);
    temp (vertex_idx_new == 1) = ...
        1:length( vertex_idx_new (vertex_idx_new == 1));
    vertex_old_to_new(2,:) = temp;

    temp_xa = vertex_old_to_new(2,xa);
    temp_xb = vertex_old_to_new(2,xb);
    xa = temp_xa (edge_idx_new == 1);
    xb = temp_xb (edge_idx_new == 1);
    oab = oab(edge_idx_new == 1);

    X = X([vertex_idx_new,vertex_idx_new,edge_idx_new]==1); 
    n = max([xa,xb]);
    m = length(xa);
    if m == 0
        return;
    end
    
    M = sparse([xa,xb],[xb,xa],ones(1,2*m),n,n,2*m);
    valency_of_vertices = sum( M ~= 0 );
    corners = find(valency_of_vertices == 2);
    K = sparse([xa,xb],[xb,xa],[oab,oab],n,n,2*m);
    
    num_corners = length(corners);
    vec_0 = zeros(1,num_corners);
    xa = [xa, vec_0];
    xb = [xb, vec_0];
    oab = [oab, vec_0];
    X = [X(1:n); vec_0'; X(n+1:2*n); vec_0'; X(2*n+1:end); vec_0'];
    
    vertedge_idx = 1;
    for k=corners
        % three orientations, 1, 2 and 3
        ab_new = 6 - sum(K(k,:));
        if isempty(find(xa==k, 1))
            xb_new = k;
            xa_new = n+vertedge_idx;
            v = -r(:,ab_new);
        else
            xa_new = k;
            xb_new = n+vertedge_idx;
            v = r(:,ab_new);
        end
        
        x0 = X([k,k+n+num_corners]);
        alpha = argument(fun,x0,v,varargin{:});
        alpha = alpha( ~isnan(alpha) );
        alpha = alpha (alpha > 0);
        alpha = min(alpha);
%         if ~isempty(alpha)
            vertex_aux = x0 + alpha*v; 
            edge_aux = alpha;
%         else
%             vertex_aux = x0;
%             edge_aux = 0;
%         end
        
        xa(m+vertedge_idx) = xa_new;
        xb(m+vertedge_idx) = xb_new;
        oab(m+vertedge_idx) = ab_new;
        X([n+vertedge_idx, num_corners+2*n+vertedge_idx, ...
            m+2*(n+num_corners)+vertedge_idx]) = ...
            [vertex_aux(1),vertex_aux(2),edge_aux];
        vertedge_idx = vertedge_idx + 1;
    end
    m = length(xa);
    n = max([xa,xb]);
    if m==0
        return;
    end
    K = sparse([xa,xb],[xb,xa],ones(1,2*m),n,n,2*m);
    G = graph(K);
    if sum(conncomp(G)) > n
        %graph is disconnected
        return;
    end
    
    stat.X = X;
    stat.xa = xa;
    stat.xb = xb;
    stat.oab = oab;
    stat.n = n;
    stat.m = m;
end

function alpha = argument(fun, x0,v,varargin)

    if isnan(v(1)) || isnan(v(2))
        v = [nan;nan];
    end
    M = 10000;
    t = linspace(.1,2*pi+.1,100);
    L1 = [x0 - M*v, x0 + M*v];
    L2 = feval(fun,t,varargin{:});
    [x,y] =  polyxpoly(L1(1,:),L1(2,:),L2(1,:),L2(2,:));
    P = [x';y'];
    
    if isempty(P)
        alpha = zeros(2,0);
    else
        n = size(P,2);
        alpha = zeros(n,1);
        for k=1:n
            alpha(k) = sign((P(1,k)-x0(1)) / v(1)) * norm(P(:,k)-x0,2);
        end
    end

%     t = NaN(n,1);
end

