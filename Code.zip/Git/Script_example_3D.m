%% Example of a carving resulting in a critical net in 3D
% (If runtime gives an error - from the numerical solver - rerun the
% script.) Increase 'eta' for a more dense embedding (and slower runtime).
clc; clear; close all;
eta = 6; % > 1
D = 10;
figure
P = CreateConvexPacking(D,eta,'Centered','Regular');
xa = P.xa;
xb = P.xb;
n = max([P.xa,P.xb]);
vertices = [P.X(1:n)';P.X(n+1:2*n)'];
subplot(2,4,1);
DisplayNet(vertices,P.xa,P.xb,1);
save("External/3D_11.mat",'vertices','xa','xb');
%%
P = CreateConvexPacking(D,eta,'Centered','Random');
n = max([P.xa,P.xb]);
vertices = [P.X(1:n)';P.X(n+1:2*n)'];
subplot(2,4,2);
DisplayNet(vertices,P.xa,P.xb,1);
save("External/3D_22.mat",'vertices','xa','xb');
%%
[~,l,center] = CalculateRatio(P.X,P.xa,P.xb);
R = l/2*.5;
curve = @(t) R*[cos(t);sin(t)] + center;
vertices = [P.X(1:n)';P.X(n+1:2*n)'];
subplot(2,4,3);
DisplayNet(vertices,P.xa,P.xb,1);
hold on
T = linspace(0,2*pi,200);
XYZ = [curve(T);R*sin(2*T)];
h3 = plot(XYZ(1,:),XYZ(2,:),'-r');
hold off
save("External/3D_33.mat",'R','center');

%%
G = CarvePacking(curve, P.X, P.xa, P.xb, P.oab);
X0 = G.X;
xa = G.xa;
xb = G.xb;
oab = G.oab;
n = max([xa,xb]);
m = length(xa);

vertices = [X0(1:n)';X0(n+1:2*n)'];
subplot(2,4,4)
DisplayNet(vertices,xa,xb,1);
vertices = [vertices;zeros(1,n)];
save("External/3D_44.mat",'vertices','xa','xb');

%%
subplot(2,4,5)
DisplayNet(vertices,xa,xb,1);
hold on
t = linspace(0,2*pi,200);
xy = curve(t);
o = length(t);
xyz = zeros(3,o);
options = optimoptions('lsqnonlin','SpecifyObjectiveGradient',true, ...
    'CheckGradients',false,'MaxIterations',1e4, ...
    'Algorithm', 'trust-region-reflective',...
    'StepTolerance',1e-10, ...
    'MaxFunctionEvaluations', 2e4);
for i=1:o
    fun = @(w) eqns_rj(w,xy(1,i),xy(2,i));
    [a,~] = lsqnonlin(fun,zeros(2,1),[],[],options);
    [xyz(1,i),xyz(2,i),xyz(3,i)] = enp(a(1),a(2));
end
plot3(xyz(1,:),xyz(2,:),xyz(3,:),'-r')
hold off
save("External/3D_55.mat",'xyz');


S = sparse([xa,xb],[xb,xa],ones(1,2*m),n,n,2*m);
V = sum(S~=0);
pX = vertices(:,V==1);
intX = vertices(:,V==2 | V==3);
num_bounds = size(pX,2);
t = angle(pX(1,:) + 1i*pX(2,:))';
x = cos(t)*R + center(1);
y = sin(t)*R + center(2);
o = length(t);
options = optimoptions('lsqnonlin','SpecifyObjectiveGradient',true, ...
    'CheckGradients',false,'MaxIterations',1e4, ...
    'Algorithm', 'trust-region-reflective',...
    'StepTolerance',1e-10, ...
    'MaxFunctionEvaluations', 2e4);
h = zeros(o,1);
for i=1:o
    fun = @(w) eqns_rj(w,x(i),y(i));
    [a,f] = lsqnonlin(fun,zeros(2,1),[],[],options);
    h(i) = -12*a(1)*a(2);
end
clc;
pX(3,:) = h';
intX = reshape(intX,size(intX,1)*size(intX,2),1);
save("External/3D_66.mat",'intX','pX');

%% Solve
fun = @(x) fundfun_length(x,xa,xb,pX);
options = optimoptions('fminunc','SpecifyObjectiveGradient',true, ...
    'CheckGradients',false,...
    'MaxIterations',1e5,...
    'StepTolerance',1e-6);
[x_opt,f] = fminunc(fun,intX,options);
clc;
fprintf("objective value: f = " + f + " ~= 0? \n");
vertices =  [reshape(x_opt,3,length(x_opt)/3),pX];
save("External/3D_77.mat",'vertices','xa','xb','oab');
%%
subplot(2,4,6)
DisplayNet(vertices,xa,xb,1);
hold on
plot3(xyz(1,:),xyz(2,:),xyz(3,:),'r')
hold off

%%
subplot(2,4,7:8)
DisplayNet(vertices,xa,xb,1);
hold on
u = linspace(-.4,.4,50);
v = linspace(-.4,.4,50);
[U,V] = meshgrid(u,v);
[X,Y,Z] = enp(U,V);
s = surf(X,Y,Z,'FaceAlpha',0.2);
s.EdgeColor = 'none';
save("External/3D_88.mat",'s');
hold off

function [x,y,z] = enp(u,v)
    x = 6.*v.*u.^2-2.*v.^3-6.*v;
    y = -2.*u.^3+6.*u.*v.^2-6.*u;
    z = -12.*u.*v;
end
function [r,J] = eqns_rj (h, x, y)
    r = zeros(2,1);
    J = zeros(2,2);
    u = h(1);
    v = h(2);
    
    r(1) = 6*v*u^2 - 2*v^3 - 6*v - x;
    r(2) = -2*u^3 + 6*u*v^2 - 6*u - y;
    
    J(1,1) = 12*u*v; %dr1 / du
    J(2,1) = -6*u^2+6*v^2-6; %dr2 / du

    J(1,2) = 6*u^2 -6*v^2 -6; %dr1 / dv
    J(2,2) = 12*u*v;%dr2 / dv
end
