function P = CreateConvexPacking(D,eta,type,generator)
stat0 = AssemblePacking(eta,type);
stat0 = SolveLinearSystem(stat0.xa,stat0.xb,stat0.oab,D,generator);
P.X = stat0.X;
P.xa = stat0.xa;
P.xb = stat0.xb;
P.oab = stat0.oab;
P.dof = stat0.dof;

end