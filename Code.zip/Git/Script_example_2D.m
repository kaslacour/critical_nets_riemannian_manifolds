%% Example of a carving resulting in a critical net in 2D
l_min = 10;
eta = 3;
P  = CreateConvexPacking(l_min,eta,'Centered','Random');
G = CarvePacking(@heart, P.X, P.xa, P.xb, P.oab, l_min);

figure
subplot(1,2,1)
DisplayNet(P.X,P.xa,P.xb,0);
hold on
T = linspace(0,2*pi,200);
XY = heart(T,l_min);
plot(XY(1,:),XY(2,:),'-k')
hold off
subplot(1,2,2)
DisplayNet(G.X,G.xa,G.xb,0);


function f = heart(t,D)
    f = [(16*sin(t).^3);(13*cos(t)-5*cos(2*t)-2*cos(3*t)-cos(4*t))];
    f = f / 16;
    f = D/2*f;
end
