% Setup of experiment
clc; clear; close all;
N = 10^3; %<- lite, %10^4 <- original
try
    U = load('External/Experiment.mat');
    minratio = U.minratio;
    maxratio = U.maxratio;
catch
    minratio = inf(1e3);
    maxratio = zeros(1e3);
end

%% The experiment
for k=1:N
    [ratio, stat_t] = GenerateRandomCriticalNet();
    if isempty(stat_t) || isnan(ratio)
        continue;
    end
    if ratio > maxratio(stat_t.pX_length) 
        stat = stat_t;
        maxratio(stat.pX_length) = ratio;
        X = stat.X;
        xa = stat.xa;
        xb = stat.xb;
        oab = stat.oab;
        num_bounds = stat.pX_length;
        savefile = "X_" + stat.pX_length + ".mat";
        save("External/"+savefile,'X','xa','xb','oab','num_bounds');
    end
    
    if ratio < minratio(stat_t.pX_length)    
        stat = stat_t;
        minratio(stat.pX_length) = ratio;
        X = stat.X;
        xa = stat.xa;
        xb = stat.xb;
        oab = stat.oab;
        num_bounds = stat.pX_length;
        savefile = "X_" + stat.pX_length + "_min.mat";
        save("External/"+savefile,'X','xa','xb','oab','num_bounds');
    end
    
end
save("External/"+"Experiment.mat",'minratio','maxratio');
%%
n_included = 3*3; % <- lite, 3*8 <- original
experiment = load("External/"+"Experiment.mat");
maxratio = experiment.maxratio;
indices = find(maxratio ~= 0);
%% Improve each 'best graph'
%max
for k=1:n_included
    idx = indices(k);
    M = load("External/"+"X_" + idx + ".mat");
    X = M.X;
    xa = M.xa;
    xb = M.xb;
    oab = M.oab;
    n = max([xa,xb]);
    m = length(xa);
    num_bounds = M.num_bounds;
    [A,b,N_edges] = SetupLinearSystem(xa,xb,oab);
    fun = @(S) -fun_ratio(S,A,b,N_edges,xa,xb);
    S0 =  X(2*n+1:end)' / (N_edges');
    num_vars = length(S0);
    option = optimset('MaxFunEvals',1000*num_vars,'MaxIter', 1000*num_vars);
    [S,ratio] = fminsearch(fun,S0,option);
    ratio = -ratio;
    

    b_edges = S * N_edges';
    small = min(b_edges);
    if small <= 0 
        b_edges = b_edges - small + eps;
    end
    b(2*m+1:end-2) = b_edges;
    X = A \ b;
    
    savefile = "External/"+"X_" + num_bounds + "_opt.mat";
    save(savefile,'X','xa', 'xb', 'oab', 'num_bounds');
end
%% Improve each 'worst graph'
%min
for k=1:n_included
    idx = indices(k);
    M = load("External/"+"X_" + idx + "_min.mat");
    X = M.X;
    xa = M.xa;
    xb = M.xb;
    oab = M.oab;
    n = max([xa,xb]);
    m = length(xa);
    num_bounds = M.num_bounds;
    [A,b,N_edges] = SetupLinearSystem(xa,xb,oab);
    fun = @(S) fun_ratio(S,A,b,N_edges,xa,xb);
    S0 =  X(2*n+1:end)' / (N_edges');
    option = optimset('MaxFunEvals',1000*num_vars,'MaxIter', 1000*num_vars);
    [S,ratio] = fminsearch(fun,S0,option);
    ratio = -ratio;
    

    b_edges = S * N_edges';
    small = min(b_edges);
    if small <= 0 
        b_edges = b_edges - small + eps;
    end
    b(2*m+1:end-2) = b_edges;
    X = A \ b;
    
    savefile = "External/"+"X_" + num_bounds + "_min_opt.mat";
    save(savefile,'X','xa', 'xb', 'oab', 'num_bounds');
end
%% Display
%Display 'best' graphs with redefined ratio
clc; close all;
figure('Name','max - unimproved - redefined ratio')
for k=1:n_included
    subaxis(ceil( n_included / 3), 3, k, ...
        'sh', 0.1, 'sv', 0.02, 'padding', 0, 'margin', 0.1);
    idx = indices(k);
    filename = "External/"+"X_"+idx+".mat";
    U = load(filename);
    [ratio,l,center,L,theta] = ...
        CalculateAlternativeRatio(U.X,U.xa,U.xb);
    DisplayMat(filename,0);
    hold on
    plot([0,l/2*cos(theta)]+center(1),[0,l/2*sin(theta)]+center(2));
    plot([0,l/2*cos(theta+pi/2)]+center(1),[0,l/2*sin(theta+pi/2)]+center(2));
    hold off
    title("pX: " + idx + ", ratio = " + ratio)
%     set(gca,'visible','off')
    set(gca,'XColor', 'none','YColor','none')
end
figure('Name','max - improved - redefined ratio')
for k=1:n_included
    subaxis(ceil( n_included / 3), 3, k, ...
        'sh', 0.1, 'sv', 0.02, 'padding', 0, 'margin', 0.1);
    idx = indices(k);
    filename = "External/"+"X_"+idx+"_opt.mat";
    U = load(filename);
    [ratio,l,center,L,theta] = ...
        CalculateAlternativeRatio(U.X,U.xa,U.xb);
    DisplayMat(filename,0);
    hold on
    plot([0,l/2*cos(theta)]+center(1),[0,l/2*sin(theta)]+center(2));
    plot([0,l/2*cos(theta+pi/2)]+center(1),[0,l/2*sin(theta+pi/2)]+center(2));
    hold off
    title("pX: " + idx + ", ratio = " + ratio)
%     set(gca,'visible','off')
    set(gca,'XColor', 'none','YColor','none')
end
% Display 'worst' graphs with redefined ratio
figure('Name','min - unimproved - redefined ratio')
for k=1:n_included
    subaxis(ceil( n_included / 3), 3, k, ...
        'sh', 0.1, 'sv', 0.02, 'padding', 0, 'margin', 0.1);
    idx = indices(k);
    filename = "External/"+"X_"+idx+"_min.mat";
    U = load(filename);
    ratio = CalculateRatio(U.X,U.xa,U.xb);
    DisplayMat(filename,0);
    title("pX: " + idx + ", ratio = " + ratio)
%     set(gca,'visible','off')
    set(gca,'XColor', 'none','YColor','none')
end
figure('Name','min - improved - redefined ratio')
for k=1:n_included
    subaxis(ceil( n_included / 3), 3, k, ...
        'sh', 0.1, 'sv', 0.02, 'padding', 0, 'margin', 0.1);
    idx = indices(k);
    filename = "External/"+"X_"+idx+"_min_opt.mat";
    U = load(filename);
    ratio = CalculateRatio(U.X,U.xa,U.xb);
    DisplayMat(filename,0);
    title("pX: " + idx + ", ratio = " + ratio)
    set(gca,'XColor', 'none','YColor','none')
end
% Display unimproved graphs with 'old' ratio
figure('Name','unimproved - old ratio')
for k=1:n_included
    subaxis(ceil( n_included / 4), 4, 2*(k-1)+1, ...
        'sh', 0.01, 'sv', 0.001, 'padding', 0.01, 'margin', 0.001);
    idx = indices(k);
    filename = "External/"+"X_"+idx+".mat";
    U = load(filename);
    DisplayMat(filename,0);
    [ratio,l,center,L,theta] = ...
        CalculateRatio(U.X,U.xa,U.xb);
    hold on
    plot([0,l/4*cos(theta)]+center(1),[0,l/4*sin(theta)]+center(2),'-r');
    hold off
    title("|pX|: " + idx + ", ratio = " + ratio)
%     set(gca,'visible','off')
    set(gca,'XColor', 'none','YColor','none')
    
    subaxis(ceil( n_included / 4), 4, 2*k, ...
    'sh', 0.01, 'sv', 0.001, 'padding', 0.01, 'margin', 0.001);
    idx = indices(k);
    filename = "External/"+"X_"+idx+"_min.mat";
    U = load(filename);
    DisplayMat(filename,0);
    [ratio,l,center,L,theta] = ...
        CalculateRatio(U.X,U.xa,U.xb);
    hold on
    plot([0,l/4*cos(theta)]+center(1),[0,l/4*sin(theta)]+center(2),'-r');
    hold off
    title("|pX|: "+idx+", ratio = " + ratio)
%     set(gca,'visible','off')
    set(gca,'XColor', 'none','YColor','none')
end
% Display improved graphs with 'old' ratio
figure('Name','improved - old ratio')
for k=1:n_included
    subaxis(ceil( n_included / 4), 4, 2*(k-1)+1, ...
        'sh', 0.01, 'sv', 0.001, 'padding', 0.01, 'margin', 0.001);
    idx = indices(k);
    filename = "External/"+"X_"+idx+"_opt.mat";
    U = load(filename);
    DisplayMat(filename,0);
    [ratio,l,center,L,theta] = ...
        CalculateRatio(U.X,U.xa,U.xb);
    hold on
    plot([0,l/4*cos(theta)]+center(1),[0,l/4*sin(theta)]+center(2),'-r');
    hold off
    title("|pX|: " + idx + ", ratio = " + ratio)
%     set(gca,'visible','off')
    set(gca,'XColor', 'none','YColor','none')
    
    subaxis(ceil( n_included / 4), 4, 2*k, ...
    'sh', 0.01, 'sv', 0.001, 'padding', 0.01, 'margin', 0.001);
    idx = indices(k);
    filename = "External/"+"X_"+idx+"_min_opt.mat";
    U = load(filename);
    DisplayMat(filename,0);
    [ratio,l,center,L,theta] = ...
        CalculateRatio(U.X,U.xa,U.xb);
    hold on
    plot([0,l/4*cos(theta)]+center(1),[0,l/4*sin(theta)]+center(2),'-r');
    hold off
    title("|pX|: "+idx+", ratio = " + ratio)
%     set(gca,'visible','off')
    set(gca,'XColor', 'none','YColor','none')
end