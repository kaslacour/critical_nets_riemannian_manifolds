function stat = AssemblePacking(eta,str)
    if str=="Centered"
        m = 9*eta^2-12*eta+3;
        xa = zeros(1,m);
        xb = zeros(1,m);
        oab = zeros(1,m);
%         dof = 3*(eta^2 - 1);
        x_0 = 1;
        e_0 = 1;
        for k=-1:eta-2
            [xa_t,xb_t,ab_t,x0_t] = path_center(x_0,eta+k,eta,true);
            m_t = length(xa_t);
            e_idx = (1:m_t) + e_0-1;
            xa(e_idx) = xa_t;
            xb(e_idx) = xb_t;
            oab(e_idx) = ab_t;
            x_0 = x0_t;
            e_0 = e_0 + m_t;
        end
        for k=eta-2:-1:0
            [xa_t,xb_t,ab_t,x0_t] = path_center(x_0,eta+k,eta,false);
            m_t = length(xa_t);
            e_idx = (1:m_t) + e_0-1;
            xa(e_idx) = xa_t;
            xb(e_idx) = xb_t;
            oab(e_idx) = ab_t;
            x_0 = x0_t;
            e_0 = e_0 + m_t;
        end
    elseif str=="Symmetric"
        m = 9*eta^2-3*eta;
        xa = zeros(1,m);
        xb = zeros(1,m);
        oab = zeros(1,m);
%         dof = 
        x_0 = 1;
        e_0 = 1;
        for k=0:eta-1
            [xa_t,xb_t,ab_t,x0_t] = path_sym(x_0,eta+k,eta,true);
            m_t = length(xa_t);
            e_idx = (1:m_t) + e_0-1;
            xa(e_idx) = xa_t;
            xb(e_idx) = xb_t;
            oab(e_idx) = ab_t;
            x_0 = x0_t;
            e_0 = e_0 + m_t;
        end
        for k=eta-1:-1:0
            [xa_t,xb_t,ab_t,x0_t] = path_sym(x_0,eta+k,eta,false);
            m_t = length(xa_t);
            e_idx = (1:m_t) + e_0-1;
            xa(e_idx) = xa_t;
            xb(e_idx) = xb_t;
            oab(e_idx) = ab_t;
            x_0 = x0_t;
            e_0 = e_0 + m_t;
        end
    end
    n = max([xa,xb]);
    stat.m = m;
    stat.n = n;
    stat.xa = xa;
    stat.xb = xb;
    stat.oab = oab;
end


function [xa,xb,ab,x0] = path_center(x0,k,eta,flag)
    if flag
        xa = x0-1 + (1:2*k); %xa=1,3, 3,5, ...
        xa(2:2:end) = xa(2:2:end)+1;
        xb = x0-1 + (1:2*k); %xb=2,2, 4,4, ...
        xb(1:2:end) = xb(1:2:end)+1;
        ab = repmat([2,1],1,k);
        
        if k < 2*eta-2
            xa = [xa, x0 + (0:2:2*k)];
            xb = [xb, x0 + (0:2:2*k) + 2*(k+1)];
            ab = [ab, 3*ones(1,k+1)];
        elseif k == 2*eta-2
            xa = [xa, x0 + (0:2:2*k)];
            xb = [xb, x0 + (0:2:2*k) + 2*k+1];
            ab = [ab, 3*ones(1,k+1)];
        end
        %ab
        x0 = x0 + 2*k + 1;
    end
    
    if ~flag
        xa = x0-1 + (1:2*k); %xa=2,2, 4,4, ...
        xa(1:2:end) = xa(1:2:end)+1;
        xb = x0-1 + (1:2*k); %xb=1,3, 3,5, ...
        xb(2:2:end) = xb(2:2:end)+1;
        ab = repmat([1,2],1,k);
        
        if k > eta 
            xa = [xa, x0-1 + (2:2:2*k)];
            xb = [xb, x0-1 + (2:2:2*k) + 2*k];
            ab = [ab, 3*ones(1,k)];
        end
        x0 = x0 + 2*k + 1;
    end
end

function [xa,xb,ab,x0] = path_sym(x0,k,eta,flag)
    if flag
        xa = x0-1 + (1:2*k); %xa=1,3, 3,5, ...
        xa(2:2:end) = xa(2:2:end)+1;
        xb = x0-1 + (1:2*k); %xb=2,2, 4,4, ...
        xb(1:2:end) = xb(1:2:end)+1;
        ab = repmat([2,1],1,k);
        
        if k < 2*eta-1
            xa = [xa, x0 + (0:2:2*k)];
            xb = [xb, x0 + (0:2:2*k) + 2*(k+1)];
            ab = [ab, 3*ones(1,k+1)];
        elseif k == 2*eta-1
            xa = [xa, x0 + (0:2:2*k)];
            xb = [xb, x0 + (0:2:2*k) + 2*k+1];
            ab = [ab, 3*ones(1,k+1)];
        end
        %ab
        x0 = x0 + 2*k + 1;
    end
    
    if ~flag
        xa = x0-1 + (1:2*k); %xa=2,2, 4,4, ...
        xa(1:2:end) = xa(1:2:end)+1;
        xb = x0-1 + (1:2*k); %xb=1,3, 3,5, ...
        xb(2:2:end) = xb(2:2:end)+1;
        ab = repmat([1,2],1,k);
        
        if k > eta 
            xa = [xa, x0-1 + (2:2:2*k)];
            xb = [xb, x0-1 + (2:2:2*k) + 2*k];
            ab = [ab, 3*ones(1,k)];
        end
        x0 = x0 + 2*k + 1;
    end
end

