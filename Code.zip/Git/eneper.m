function [x,y,z] = eneper(u,v)
    x = 6.*v.*u.^2-2.*v.^3-6.*v;
    y = -2.*u.^3+6.*u.*v.^2-6.*u;
    z = -12.*u.*v;
end