function [r,J] = fun_rj_length(intX,xa,xb,pX)

m = length(xa);

% X is the 3-by-n matrix containing the 3d points of each vertex, where
% exceptionally, n is the number of interior vertices
n = length(intX) / 3;
intX = reshape(intX,3,n);

% pX is the 3-by-pm matrix containing the 3d points of each boundary
% vertex, where pm is the number of boundary vertices / stem edges
pm = size(pX,2);

% [xa,xb] represents the pairs of vertices that constitute the edges, 
% where xa and xb are the indices of the vertices in question
    
X = [intX,pX];

r = zeros(3*n,1);
J = zeros(3*n,3*n);
for i=1:m-pm
    Xa = X(:,xa(i)); 
    Xb = X(:,xb(i)); 
    vector_ab = (Xb - Xa);
    vector_ba = - vector_ab;
    length_ab = norm(Xb-Xa,2);
    unit_vector_ab = vector_ab / length_ab;
    unit_vector_ba = vector_ba / length_ab;
    r_idx_a = 3*(xa(i)-1);
    r_idx_b = 3*(xb(i)-1);
    r(r_idx_a + (1:3)) = r(r_idx_a + (1:3)) + unit_vector_ab;
    r(r_idx_b + (1:3)) = r(r_idx_b + (1:3)) + unit_vector_ba;
    
    if nargout < 2
        continue;
    end
    
    for k=1:3
        not_k = [1:k-1,k+1:3];
        d_1 = - 1 / length_ab + vector_ab(k)^2 / length_ab^3;
        d_2 = vector_ab(k) * vector_ab(not_k)' / length_ab^3;
        d_3 = 1 / length_ab - vector_ab(k)^2 / length_ab^3;
        d_4 = - vector_ab(k) * vector_ab(not_k)' / length_ab^3;
        
        J_idx = [r_idx_a+k,r_idx_a+not_k,r_idx_b+k,r_idx_b+not_k];
        J(r_idx_a+k,J_idx) = J(r_idx_a+k,J_idx) + ...
            [d_1,d_2,d_3,d_4];
        
        d_1 = - 1 / length_ab + vector_ba(k)^2 / length_ab^3;
        d_2 = vector_ba(k) * vector_ba(not_k)' / length_ab^3;
        d_3 = 1 / length_ab - vector_ba(k)^2 / length_ab^3;
        d_4 = - vector_ba(k) * vector_ba(not_k)' / length_ab^3;
        
        J_idx = [r_idx_b+k,r_idx_b+not_k,r_idx_a+k,r_idx_a+not_k];
        J(r_idx_b+k,J_idx) = J(r_idx_b+k,J_idx) + ...
            [d_1,d_2,d_3,d_4];
    end
    
end
for i=(1:pm)+m-pm
    Xa = X(:,xa(i)); 
    Xb = X(:,xb(i)); 
    vector_ab = (Xb - Xa);
    vector_ba = - vector_ab;
    length_ab = norm(Xb-Xa,2);
    unit_vector_ab = vector_ab / length_ab;
    unit_vector_ba = vector_ba / length_ab;

    if xa(i) > n
        r_idx_b = 3*(xb(i)-1);
        r(r_idx_b + (1:3)) = r(r_idx_b + (1:3)) + unit_vector_ba;
        if nargout < 2
            continue;
        end
        for k=1:3
            not_k = [1:k-1,k+1:3];
            d_1 = - 1 / length_ab + vector_ba(k)^2 / length_ab^3;
            d_2 = vector_ba(k) * vector_ba(not_k)' / length_ab^3;

            J_idx = [r_idx_b+k,r_idx_b+not_k];
            J(r_idx_b+k,J_idx) = J(r_idx_b+k,J_idx) + ...
                [d_1,d_2];
        end
    else
        r_idx_a = 3*(xa(i)-1);
        r((1:3) + r_idx_a) = r((1:3) + r_idx_a) + unit_vector_ab;
        if nargout < 2
            continue;
        end
        for k=1:3
            not_k = [1:k-1,k+1:3];
            d_1 = - 1 / length_ab + vector_ab(k)^2 / length_ab^3;
            d_2 = vector_ab(k) * vector_ab(not_k)' / length_ab^3;

            J_idx = [r_idx_a+k,r_idx_a+not_k];
            J(r_idx_a+k,J_idx) = J(r_idx_a+k,J_idx) + ...
                [d_1,d_2];
        end
    end
end

end


