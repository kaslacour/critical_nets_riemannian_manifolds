function [ratio,stat] = GenerateRandomCriticalNet()
ratio = nan;
D = 10;
centered = randi([0,1]);
if centered
    eta = randi([2,7]);
    stat0 = AssemblePacking(eta,'Centered');
else
    eta = randi([1,7]);
    stat0 = AssemblePacking(eta,'Symmetric');
end
stat0 = SolveLinearSystem(stat0.xa,stat0.xb,stat0.oab,D,'Random');

alpha = rand*pi/2;
beta = D*(rand(2,1)-0.5);
gamma = rand+1;
stat = CarvePacking(@curve, stat0.X, stat0.xa, stat0.xb, ...
    stat0.oab, D, alpha,beta,gamma);

if isempty(stat)
    return;
end

stat = InteriorGraph(stat.X,stat.xa,stat.xb,stat.oab);
if isempty(stat)
    return;
end
ratio = stat.L / stat.l / stat.pX_length;
end

function f = curve(t,D,alpha,beta,gamma)
    f = gamma*D/2*[cos(alpha)*cos(t);sin(alpha)*sin(t)];
    f = f + beta;
end

