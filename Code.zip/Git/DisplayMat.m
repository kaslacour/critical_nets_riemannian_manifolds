function [] = DisplayMat(filename,flag)
    S = load(filename);
    n = max([S.xa,S.xb]);
    if flag==0
        X = S.X;
        vertices = [X(1:n)';X(n+1:2*n)'];
    elseif flag==1
        vertices = S.vertices;
    end
    DisplayNet(vertices,S.xa,S.xb,1);
%     set(gca,'visible','off')
%     set(gca,'XColor', 'none','YColor','none')
end

