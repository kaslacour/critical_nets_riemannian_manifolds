function stat = InteriorGraph(X,xa,xb,oab)
    stat = [];    
    if isempty(X) || isempty(xa) || isempty(xb) || isempty(oab)
        return;
    end
    
    n = max([xa,xb]);
    m = length(oab);    
    S = sparse([xa,xb],[xb,xa],ones(1,2*m),n,n,2*m);
    V = sum(S ~= 0);
    vertices = [X(1:n)';X(n+1:2*n)'];
    pX_labels = find(V==1);
    pX = vertices(:,V==1);
    
    stat = DeleteVertices(X,xa,xb,oab,pX_labels);
    if isempty(stat)
        return;
    end
    X = stat.X;
    xa = stat.xa;
    xb = stat.xb;
    oab = stat.oab;
    if isempty(X) || isempty(xa) || isempty(xb) || ...
            isempty(oab) || min([xa,xb]) ~=1
        stat = [];
        return;
    end
    n = max([xa,xb]);
    m = length(oab);
    
    if length(X) ~= 2*n + m
        stat = [];
        return;
    end
    
    S = sparse([xa,xb],[xb,xa],ones(1,2*m),n,n,2*m);
    V = sum(S ~= 0);
    vertices = [X(1:n)';X(n+1:2*n)'];
    outer_vertices = vertices(:,V==1 | V==2);
    fun = @(theta) fun_radius(theta,outer_vertices);
    theta = fminsearch(fun,0);
    [l,center] = fun(theta);
    X(1:n) = X(1:n) - center(1);
    X(n+1:2*n) = X(n+1:2*n) - center(2);


    L = sum(X(2*n+1:end));
    
    stat.X = X;
    stat.theta = theta;
    stat.l = l;
    stat.L = L;
    stat.xa = xa;
    stat.xb = xb;
    stat.oab = oab;
    stat.pX = pX;
    stat.pX_length = size(pX,2);
    stat.outer_vertices = outer_vertices;
    stat.n = n;
    stat.m = m;
end

