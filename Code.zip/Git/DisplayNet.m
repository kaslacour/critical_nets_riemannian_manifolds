function h = DisplayNet(X,xa,xb,flag)


    if isempty(X) || isempty(xa)
        return;
    end
    n = max([xa,xb]);
    m = length(xa);
    
    if flag == 0
        if length(X) == 2*n + m
            X = [X(1:n)';X(n+1:2*n)'];
        elseif length(X) == 3*n + m
            X = [X(1:n)';X(n+1:2*n)';X(2*n+1:3*n)'];
        else
            error('X has invalid length')
        end
    end
    
    M = sparse([xa, xb],[xb, xa],ones(1,2*m),n,n,2*m);
    valencies = sum( M(:,:) ~= 0 );
    leaves = find(valencies == 1);
    K = sparse([xa,xb],[xb,xa],ones(1,2*m),n,n,2*m);
    
    G = graph(K);
    if size(X,1) == 3
        h = plot(G,'XData',X(1,:),'YData',X(2,:),'ZData',X(3,:));
    elseif size(X,1) == 2
        h = plot(G,'XData',X(1,:),'YData',X(2,:));
    end
    labelnode(h,1:n,'')
    highlight(h,leaves,'NodeColor','g')
    axis equal
end

