function [f,df] = fundfun_length(intX,xa,xb,pX)

if nargout == 1
    r = fun_rj_length(intX,xa,xb,pX);
else
    [r,J] = fun_rj_length(intX,xa,xb,pX);
    df = J' * r;
end
f = 1/2 * norm(r,2)^2;

end


