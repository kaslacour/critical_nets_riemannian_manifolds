function [ratio,l,center,L,theta] = CalculateRatio(X,xa,xb)
    m = length(xa);
    n = max([xa,xb]);
    %finds smallest l-ball
    L = sum(X(2*n+1:end));
    S = sparse([xa,xb],[xb,xa],ones(1,2*m),n,n,2*m);
    V = sum(S~=0);
    vertices = [X(1:n)';X(n+1:2*n)'];
    corners = vertices(:, V == 2);
    leaves = vertices(:, V == 1);
    outer_vertices = [corners,leaves];
    num_bounds = size(corners,2) + 2*size(leaves,2);
    fun = @(theta) fun_radius(theta,outer_vertices);
    theta = fminsearch(fun,0);
    [l,center] = fun_radius(theta,outer_vertices);
    %finally, we calculate the ratio
    ratio = L / l / num_bounds;
end

